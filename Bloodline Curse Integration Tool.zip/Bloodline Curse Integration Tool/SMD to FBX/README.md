# SMD 转 OBJ 转换脚本

将 **Valve 引擎的 SMD**（Studiomdl Data，常用于 Source 引擎游戏）模型转换为 **OBJ** 格式。

## 环境要求

- Python 3.6+
- 命令行脚本无第三方依赖（仅标准库）
- **拖放窗口** 建议安装 `windnd` 以支持拖拽：`pip install windnd`
- **可选：同时导出 FBX** 需安装 pyassimp 及 Assimp 动态库，详见下方「如何安装 pyassimp」。

## 如何安装 pyassimp（可选，用于同时导出 FBX）

pyassimp 是 Assimp 的 Python 封装，需要两步：**安装 Python 包** + **本机有 Assimp 动态库（DLL）**。

### 第一步：安装 Python 包

在命令行中执行：

```bash
pip install pyassimp
```

若遇兼容性问题，可指定版本：

```bash
pip install pyassimp==4.1.3
```

### 第二步：准备 Assimp 动态库（Windows）

仅 `pip install pyassimp` 会报错「assimp library not found」，因为还要有 **assimp.dll**。任选其一即可：

**方式 A：vcpkg（推荐，一次装好）**

1. 安装 [vcpkg](https://vcpkg.io/)（若未安装）。
2. 在 vcpkg 目录下执行：
   ```bash
   vcpkg install assimp:x64-windows
   ```
3. 在「安装目录」的 `installed\x64-windows\bin\` 下找到 `assimp.dll`（或类似名）。
4. 把该 DLL 放到 **Python 能找到的位置** 之一：
   - 当前工作目录（运行 `python smd_drop_app.py` 的目录），或
   - `pyassimp` 包所在目录（如 `Python安装路径\Lib\site-packages\pyassimp\`），或
   - 系统 PATH 中的任意目录。

**方式 B：预编译包（免编译）**

1. 从 [Assimp 官方 itch.io](https://kimkulling.itch.io/the-asset-importer-lib) 或 [GitHub Releases](https://github.com/assimp/assimp/releases) 下载 Windows 预编译包。
2. 解压后找到 `assimp.dll`（一般在 `bin` 或 `lib` 目录）。
3. 同上，复制到上述任一位置。

**方式 C：旧版预编译（3.1.1，仅作备用）**

- 下载 [assimp-3.1.1-win-binaries.zip](https://sourceforge.net/projects/assimp/files/assimp-3.1/assimp-3.1.1-win-binaries.zip/download)，从 `bin64` 取出 `assimp.dll`，放到上述位置。

### 验证是否安装成功

在命令行执行：

```bash
python -c "import pyassimp; print('pyassimp OK')"
```

若无报错且打印 `pyassimp OK`，说明安装成功。然后打开拖放窗口，勾选「同时导出 FBX」即可在转换时一并生成 FBX。

## 拖放转换窗口（推荐，SMD → OBJ）

运行后出现窗口，**将 SMD 文件拖入窗口**即可批量转换为 OBJ，输出在与 SMD 同目录。

```bash
cd smd_to_fbx
python smd_drop_app.py
```

- 支持**批量拖入**多个 SMD 文件（需安装 `windnd`：`pip install windnd`）
- 未安装 windnd 时可用「选择文件」「选择文件夹」添加
- 输出 OBJ 与源 SMD 同路径、同名，仅扩展名改为 `.obj`

## 命令行使用方法（SMD → OBJ）

```bash
# 进入脚本目录
cd smd_to_fbx

# 转换为 OBJ（默认）
python smd_to_fbx.py 你的模型.smd -o 输出.obj
```

## 参数说明

| 参数 | 说明 |
|------|------|
| `input` | 输入的 .smd 文件路径 |
| `-o, --output` | 输出文件路径（可选，不填则用输入文件名加 .obj） |

## 支持的 SMD 内容

- 解析 **version 1** 的 SMD
- 读取 **triangles** 块中的顶点（位置、法线、UV）及骨骼权重
- 导出为**静态网格**（顶点/法线/UV 保留；骨骼动画不导出）

## 输出格式说明

- **OBJ**：通用 3D 格式，多数软件支持；会同时生成同名的 .mtl 材质文件。

## 作为模块使用

```python
from smd_to_fbx import parse_smd_file, write_obj

model = parse_smd_file("model.smd")
write_obj(model, "model.obj")
```

## 许可

本脚本仅供学习与个人使用。SMD 为 Valve 相关格式，FBX 为 Autodesk 格式，使用相关资源请遵守其各自许可与版权。
