# -*- coding: utf-8 -*-
"""
使用 Assimp（PyAssimp）将 OBJ 转为 FBX。

依赖：pip install pyassimp，且本机需有 Assimp 动态库（assimp 官方或预编译 dll/so）。
接口与 Assimp 源码一致：load(scene) → export(scene, path, file_type)。
"""
import os

try:
    import pyassimp
    from pyassimp import postprocess
    HAS_PYASSIMP = True
except Exception:
    HAS_PYASSIMP = False
    pyassimp = None
    postprocess = None


def export_obj_to_fbx(obj_path: str, fbx_path: str) -> bool:
    """
    用 Assimp 将 OBJ 导出为 FBX。成功返回 True，失败返回 False（不抛异常）。
    若未安装 pyassimp 或 Assimp 库不可用，直接返回 False。
    """
    if not HAS_PYASSIMP:
        return False
    if not os.path.isfile(obj_path):
        return False
    try:
        with pyassimp.load(
            obj_path,
            file_type=None,
            processing=postprocess.aiProcess_Triangulate
            | postprocess.aiProcess_JoinIdenticalVertices,
        ) as scene:
            pyassimp.export(
                scene,
                fbx_path,
                file_type="fbx",
                processing=postprocess.aiProcess_Triangulate,
            )
        return True
    except Exception:
        return False
