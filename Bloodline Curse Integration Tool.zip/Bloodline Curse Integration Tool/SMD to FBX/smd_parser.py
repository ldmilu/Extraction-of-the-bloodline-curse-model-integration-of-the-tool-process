# -*- coding: utf-8 -*-
"""
Valve SMD 文件解析器
支持 version 1 的静态网格与骨骼网格（仅提取几何体用于导出）
"""
import re
from dataclasses import dataclass, field
from typing import List, Tuple, Optional


@dataclass
class Vertex:
    """顶点：位置、法线、UV、骨骼权重"""
    x: float
    y: float
    z: float
    nx: float
    ny: float
    nz: float
    u: float
    v: float
    bones: List[Tuple[int, float]]  # (bone_index, weight)


@dataclass
class Triangle:
    """三角形：材质名 + 3 个顶点"""
    material: str
    v0: Vertex
    v1: Vertex
    v2: Vertex


@dataclass
class SmdModel:
    """解析后的 SMD 模型"""
    version: int = 1
    triangles: List[Triangle] = field(default_factory=list)


def _parse_vertex(line: str, next_lines: List[str], line_index: int) -> Tuple[Vertex, int]:
    """
    解析一行顶点及后续的骨骼权重行。
    常见格式:
      1) 参考/静态网格:
         parent_bone x y z nx ny nz u v
      2) 带权重网格（权重写在同一行或后续行）:
         parent_bone x y z nx ny nz u v num_bones [bone weight]...
    为了稳妥起见，我们仅使用前 9 个字段的几何数据，
    剩余内容与后续行一律忽略，避免破坏 triangles 结构。
    返回 (Vertex, 消耗的行数)，目前始终消耗 1 行。
    """
    parts = line.split()
    if len(parts) < 9:
        raise ValueError("顶点行字段不足: " + line)

    parent_bone = int(parts[0])
    x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
    nx, ny, nz = float(parts[4]), float(parts[5]), float(parts[6])
    u, v = float(parts[7]), float(parts[8])

    # 暂不区分多骨权重，默认全部权重给父骨骼
    bones: List[Tuple[int, float]] = [(parent_bone, 1.0)]
    consumed = 1
    return Vertex(x, y, z, nx, ny, nz, u, v, bones), consumed


def parse_smd(content: str) -> SmdModel:
    """
    解析 SMD 文件内容，返回 SmdModel。
    只关心 triangles 块中的几何体。
    """
    lines = content.splitlines()
    model = SmdModel()
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if stripped == "triangles":
            i += 1
            while i < len(lines):
                line = lines[i]
                stripped = line.strip()
                if stripped == "end" or not stripped:
                    break
                # 材质名（可能带引号或不含空格）
                material = stripped
                i += 1
                if i + 2 >= len(lines):
                    break
                # 三个顶点（每个顶点可能后跟骨骼权重行）
                v0, skip0 = _parse_vertex(lines[i], lines, i)
                i += skip0
                if i >= len(lines):
                    break
                v1, skip1 = _parse_vertex(lines[i], lines, i)
                i += skip1
                if i >= len(lines):
                    break
                v2, skip2 = _parse_vertex(lines[i], lines, i)
                i += skip2
                model.triangles.append(Triangle(material, v0, v1, v2))
            i += 1
            continue
        if stripped.startswith("version"):
            parts = stripped.split()
            if len(parts) >= 2:
                model.version = int(parts[1])
        i += 1
    return model


def parse_smd_file(path: str, encoding: str = "utf-8") -> SmdModel:
    """从文件路径解析 SMD。"""
    try:
        with open(path, "r", encoding=encoding) as f:
            content = f.read()
    except UnicodeDecodeError:
        with open(path, "r", encoding="latin-1") as f:
            content = f.read()
    return parse_smd(content)
