# -*- coding: utf-8 -*-
"""
SMD → OBJ drag-and-drop converter UI.

Opens a window; drop SMD files to batch-convert to OBJ (same folder by default).
Multi-select drag or use the file picker.
"""
import os
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

# 确保可导入同目录模块
APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

# 本地直接导入解析与导出函数（避免线程中再做包名判断）
from smd_parser import parse_smd_file
from export_obj import write_obj
from obj_to_fbx_assimp import export_obj_to_fbx, HAS_PYASSIMP

try:
    import windnd
    HAS_WINDND = True
except ImportError:
    HAS_WINDND = False


def convert_smd_to_fbx(smd_path, out_dir=None, name_mode="same", export_obj=True, export_fbx=False):
    """Convert one SMD per checkboxes; returns (success, message)."""

    if not os.path.isfile(smd_path):
        return False, f"File not found: {smd_path}"
    if not smd_path.lower().endswith(".smd"):
        return False, f"Not an SMD file: {os.path.basename(smd_path)}"
    if not export_obj and not export_fbx:
        return False, "Enable Export OBJ and/or Export FBX"

    try:
        model = parse_smd_file(smd_path)
        if not model.triangles:
            return False, f"No triangles: {os.path.basename(smd_path)}"

        src_dir, src_name = os.path.split(smd_path)
        base_name, _ = os.path.splitext(src_name)
        target_dir = out_dir or src_dir
        os.makedirs(target_dir, exist_ok=True)

        obj_path = os.path.join(target_dir, base_name + ".obj")
        fbx_base = (base_name + "_fbx") if name_mode == "suffix" else base_name
        fbx_path = os.path.join(target_dir, fbx_base + ".fbx")

        msg_parts = []
        obj_to_use = None  # 供 FBX 使用的 OBJ 路径（本机或临时）

        if export_obj:
            write_obj(model, obj_path)
            msg_parts.append(f"OBJ: {obj_path}")
            obj_to_use = obj_path

        if export_fbx:
            if not HAS_PYASSIMP:
                msg_parts.append("FBX: pyassimp not installed, skipped")
            else:
                # 若未导出 OBJ，则先写到临时 OBJ 再转 FBX
                if obj_to_use is None:
                    import tempfile
                    fd, obj_to_use = tempfile.mkstemp(suffix=".obj", dir=target_dir)
                    os.close(fd)
                    mtl_temp = os.path.splitext(obj_to_use)[0] + ".mtl"
                    try:
                        write_obj(model, obj_to_use)
                        if export_obj_to_fbx(obj_to_use, fbx_path):
                            msg_parts.append(f"FBX: {fbx_path}")
                    finally:
                        for p in (obj_to_use, mtl_temp):
                            try:
                                if os.path.isfile(p):
                                    os.remove(p)
                            except OSError:
                                pass
                else:
                    if export_obj_to_fbx(obj_to_use, fbx_path):
                        msg_parts.append(f"FBX: {fbx_path}")

        return True, " | ".join(msg_parts) if msg_parts else "Nothing exported"
    except Exception as e:
        return False, f"{os.path.basename(smd_path)}: {e}"


def collect_smd_files(paths: list[str]) -> list[str]:
    """Collect all .smd files from paths (recursive for folders)."""
    out = []
    for p in paths:
        p = os.path.abspath(p)
        if os.path.isfile(p) and p.lower().endswith(".smd"):
            out.append(p)
        elif os.path.isdir(p):
            for root, _, files in os.walk(p):
                for f in files:
                    if f.lower().endswith(".smd"):
                        out.append(os.path.join(root, f))
    return list(dict.fromkeys(out))  # 去重保持顺序


class DropApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("SMD → OBJ/FBX (batch)")
        self.root.minsize(680, 420)
        self.root.geometry("800x460")

        self.pending = []
        self.lock = threading.Lock()
        self.running = False

        self._build_ui()
        if HAS_WINDND:
            windnd.hook_dropfiles(self.root, func=self._on_drop)
        else:
            self._show_windnd_hint()

    def _build_ui(self):
        main = ttk.Frame(self.root, padding=12)
        main.pack(fill=tk.BOTH, expand=True)

        tip = "Drag SMD files into the area below, or use Select files to add."
        if not HAS_WINDND:
            tip = "Use Select files to add SMD files (install windnd for drag-and-drop from Explorer)."
        ttk.Label(main, text=tip, wraplength=400).pack(anchor=tk.W)

        self.drop_frame = f = ttk.LabelFrame(main, text="Drop zone / queue", padding=8)
        f.pack(fill=tk.BOTH, expand=True, pady=(8, 4))

        self.listbox = tk.Listbox(f, height=6, selectmode=tk.EXTENDED, font=("Consolas", 9))
        self.listbox.pack(fill=tk.BOTH, expand=True)
        sb = ttk.Scrollbar(f, command=self.listbox.yview)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.listbox.config(yscrollcommand=sb.set)

        # 输出目录与命名规则
        out_frame = ttk.Frame(main)
        out_frame.pack(fill=tk.X, pady=(4, 2))

        ttk.Label(out_frame, text="Output folder:").pack(side=tk.LEFT)
        self.out_dir_var = tk.StringVar(value="")
        self.out_dir_entry = ttk.Entry(out_frame, textvariable=self.out_dir_var, width=40)
        self.out_dir_entry.pack(side=tk.LEFT, padx=(4, 4), fill=tk.X, expand=True)
        ttk.Button(out_frame, text="Browse…", command=self._on_select_out_dir).pack(side=tk.LEFT)

        # 导出格式：可多选 OBJ、FBX
        export_frame = ttk.LabelFrame(main, text="Export format (multi-select)", padding=4)
        export_frame.pack(fill=tk.X, pady=(0, 4))
        ef_inner = ttk.Frame(export_frame)
        ef_inner.pack(fill=tk.X)
        self.export_obj_var = tk.BooleanVar(value=True)
        self.export_fbx_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(ef_inner, text="Export OBJ", variable=self.export_obj_var).pack(side=tk.LEFT, padx=(0, 16))
        self.cb_fbx = ttk.Checkbutton(ef_inner, text="Export FBX (needs pyassimp)", variable=self.export_fbx_var)
        self.cb_fbx.pack(side=tk.LEFT, padx=(0, 8))
        if not HAS_PYASSIMP:
            self.cb_fbx.config(state=tk.DISABLED)
        ttk.Label(ef_inner, text="Naming:").pack(side=tk.LEFT, padx=(12, 4))
        self.name_mode_var = tk.StringVar(value="same")
        ttk.Radiobutton(ef_inner, text="Same as SMD", value="same", variable=self.name_mode_var).pack(side=tk.LEFT, padx=(0, 4))
        ttk.Radiobutton(ef_inner, text="FBX with _fbx suffix", value="suffix", variable=self.name_mode_var).pack(side=tk.LEFT)

        btn_f = ttk.Frame(main)
        btn_f.pack(fill=tk.X, pady=4)
        ttk.Button(btn_f, text="Select files", command=self._on_select_files).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(btn_f, text="Select folder", command=self._on_select_folder).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(btn_f, text="Clear list", command=self._clear_list).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(btn_f, text="Start", command=self._start_convert).pack(side=tk.LEFT, padx=(0, 6))

        # 底部：共用窗口，通过点击「日志」「转换失败/无法显示模型」切换
        bottom = ttk.LabelFrame(main, text="Log / failures", padding=4)
        bottom.pack(fill=tk.BOTH, expand=True, pady=(4, 0))

        tabs_row = ttk.Frame(bottom)
        tabs_row.pack(fill=tk.X, pady=(0, 4))
        self._tab_active = "log"
        self.tab_log = ttk.Label(tabs_row, text="Log", cursor="hand2")
        self.tab_log.pack(side=tk.LEFT, padx=(0, 12))
        self.tab_log.bind("<Button-1>", lambda e: self._switch_tab("log"))
        self.tab_failed = ttk.Label(tabs_row, text="Failed / bad mesh", cursor="hand2")
        self.tab_failed.pack(side=tk.LEFT)
        self.tab_failed.bind("<Button-1>", lambda e: self._switch_tab("failed"))

        content = ttk.Frame(bottom)
        content.pack(fill=tk.BOTH, expand=True)

        self.panel_log = ttk.Frame(content)
        self.log = scrolledtext.ScrolledText(self.panel_log, height=8, font=("Consolas", 9), state=tk.DISABLED)
        self.log.pack(fill=tk.BOTH, expand=True)

        self.panel_failed = ttk.Frame(content)
        self.failed_listbox = tk.Listbox(self.panel_failed, height=8, font=("Consolas", 9), state=tk.NORMAL)
        self.failed_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        failed_sb = ttk.Scrollbar(self.panel_failed, command=self.failed_listbox.yview)
        failed_sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.failed_listbox.config(yscrollcommand=failed_sb.set)

        self.panel_log.pack(fill=tk.BOTH, expand=True)
        self._update_tab_style()

    def _switch_tab(self, name: str):
        if name == self._tab_active:
            return
        self._tab_active = name
        if name == "log":
            self.panel_failed.pack_forget()
            self.panel_log.pack(fill=tk.BOTH, expand=True)
        else:
            self.panel_log.pack_forget()
            self.panel_failed.pack(fill=tk.BOTH, expand=True)
        self._update_tab_style()

    def _update_tab_style(self):
        f9 = ("TkDefaultFont", 9)
        f9b = ("TkDefaultFont", 9, "bold")
        self.tab_log.config(font=f9b if self._tab_active == "log" else f9)
        self.tab_failed.config(font=f9b if self._tab_active == "failed" else f9)

    def _show_windnd_hint(self):
        self._log("Tip: install windnd for Explorer drag-and-drop: pip install windnd\n")

    def _log(self, msg: str):
        self.log.config(state=tk.NORMAL)
        self.log.insert(tk.END, msg)
        self.log.see(tk.END)
        self.log.config(state=tk.DISABLED)

    def _on_drop(self, files: list):
        paths = []
        for f in files:
            if isinstance(f, bytes):
                try:
                    paths.append(f.decode("utf-8"))
                except UnicodeDecodeError:
                    paths.append(f.decode("gbk"))
            else:
                paths.append(f)
        self._add_paths(paths)

    def _add_paths(self, paths: list):
        smd_list = collect_smd_files(paths)
        with self.lock:
            for p in smd_list:
                if p not in self.pending:
                    self.pending.append(p)
        self._refresh_listbox()
        if smd_list:
            self._log(f"Added {len(smd_list)} SMD file(s)\n")

    def _refresh_listbox(self):
        self.listbox.delete(0, tk.END)
        for p in self.pending:
            self.listbox.insert(tk.END, p)

    def _on_select_files(self):
        paths = filedialog.askopenfilenames(
            title="Select SMD files",
            filetypes=[("SMD models", "*.smd"), ("All files", "*.*")],
        )
        if paths:
            self._add_paths(list(paths))

    def _on_select_folder(self):
        path = filedialog.askdirectory(title="Select folder containing SMD files")
        if path:
            self._add_paths([path])

    def _on_select_out_dir(self):
        path = filedialog.askdirectory(title="Select output folder")
        if path:
            self.out_dir_var.set(path)

    def _clear_list(self):
        with self.lock:
            self.pending.clear()
        self._refresh_listbox()
        self._clear_failed_list()
        self._log("List cleared\n")

    def _start_convert(self):
        with self.lock:
            to_do = list(self.pending)
        if not to_do:
            messagebox.showinfo("Notice", "Add SMD files to convert first.")
            return
        if self.running:
            messagebox.showinfo("Notice", "Conversion already in progress.")
            return
        export_obj = self.export_obj_var.get()
        export_fbx = self.export_fbx_var.get()
        if not export_obj and not export_fbx:
            messagebox.showwarning("Notice", "Enable Export OBJ and/or Export FBX.")
            return
        if export_fbx and not HAS_PYASSIMP:
            messagebox.showwarning(
                "Notice",
                "pyassimp not found; cannot export FBX. Install pyassimp or place the Assimp DLL correctly.",
            )
            return
        self.running = True
        self._clear_failed_list()
        self._log(f"Starting conversion of {len(to_do)} file(s)…\n")
        out_dir = self.out_dir_var.get().strip() or None
        name_mode = self.name_mode_var.get()
        threading.Thread(target=self._run_convert, args=(to_do, out_dir, name_mode, export_obj, export_fbx), daemon=True).start()

    def _clear_failed_list(self):
        self.failed_listbox.delete(0, tk.END)

    def _run_convert(self, paths: list, out_dir, name_mode, export_obj: bool, export_fbx: bool):
        ok, fail = 0, 0
        failed_paths = []
        for i, p in enumerate(paths):
            success, msg = convert_smd_to_fbx(p, out_dir=out_dir, name_mode=name_mode, export_obj=export_obj, export_fbx=export_fbx)
            if success:
                ok += 1
                self.root.after(0, lambda m=msg: self._log(f"  ✓ {m}\n"))
            else:
                fail += 1
                failed_paths.append(p)
                self.root.after(0, lambda m=msg: self._log(f"  ✗ {m}\n"))
        self.root.after(0, lambda: self._convert_done(ok, fail, paths, failed_paths))

    def _convert_done(self, ok: int, fail: int, paths: list, failed_paths: list):
        self.running = False
        self._log(f"Done: succeeded {ok}, failed {fail}\n\n")
        with self.lock:
            for p in paths:
                if p in self.pending:
                    self.pending.remove(p)
        self._refresh_listbox()
        self.failed_listbox.delete(0, tk.END)
        for p in failed_paths:
            self.failed_listbox.insert(tk.END, p)
        messagebox.showinfo("Done", f"Succeeded: {ok}\nFailed: {fail}")

    def run(self):
        self.root.mainloop()


def main():
    app = DropApp()
    app.run()


if __name__ == "__main__":
    main()
