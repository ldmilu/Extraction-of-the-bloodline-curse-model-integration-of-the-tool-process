# -*- coding: utf-8 -*-
"""
将 SmdModel 导出为 FBX 二进制格式（便于 Unity 等软件正确识别）。
基于 Blender Foundation 的 FBX 二进制格式说明实现。
"""
import array
import struct
import sys
from io import BytesIO
from typing import List, Tuple
from smd_parser import SmdModel, Vertex


# Unity 6 等新版本多支持 FBX 7500+（8 字节偏移）
FBX_VERSION = 7500
HEADER_MAGIC = b"Kaydara FBX Binary  \x00"
# 7500+: EndOffset/NumProperties/PropertyListLen 各 8 字节，NULL 记录 = 8+8+8+1 = 25
NULL_RECORD_LEN = 25
USE_64BIT_HEADER = True


def _prop_s(data: str) -> bytes:
    d = data.encode("utf-8")
    return b"S" + struct.pack("<I", len(d)) + d


def _prop_i(val: int) -> bytes:
    return b"I" + struct.pack("<i", val)


def _prop_f(val: float) -> bytes:
    return b"F" + struct.pack("<f", val)


def _prop_f_array(arr: List[float]) -> bytes:
    """Float array, encoding 0 = uncompressed. 用 array 避免超长 struct 格式串导致 bad char."""
    n = len(arr)
    a = array.array("f", arr)
    if sys.byteorder != "little":
        a.byteswap()
    return b"f" + struct.pack("<III", n, 0, 0) + a.tobytes()


def _prop_i_array(arr: List[int]) -> bytes:
    """Int array, encoding 0 = uncompressed. 用 array 避免超长 struct 格式串导致 bad char."""
    n = len(arr)
    a = array.array("i", arr)
    if sys.byteorder != "little":
        a.byteswap()
    return b"i" + struct.pack("<III", n, 0, 0) + a.tobytes()


def _write_node(io: BytesIO, name: str, properties: List[bytes], children: List[Tuple[str, List[bytes], List]]) -> int:
    """写入一个节点（含子节点）。7500+ 用 8 字节偏移。"""
    start = io.tell()
    prop_list = b"".join(properties)
    num_props = len(properties)
    prop_len = len(prop_list)
    name_b = name.encode("utf-8")
    name_len = len(name_b)

    if USE_64BIT_HEADER:
        io.write(struct.pack("<QQQ", 0, num_props, prop_len))
    else:
        io.write(struct.pack("<III", 0, num_props, prop_len))
    io.write(struct.pack("<B", name_len))
    io.write(name_b)
    io.write(prop_list)

    if children:
        for cname, cprops, cchildren in children:
            _write_node(io, cname, cprops, cchildren)
        io.write(b"\x00" * NULL_RECORD_LEN)

    end_pos = io.tell()
    io.seek(start)
    if USE_64BIT_HEADER:
        io.write(struct.pack("<Q", end_pos))
    else:
        io.write(struct.pack("<I", end_pos))
    io.seek(end_pos)
    return end_pos


def write_fbx_binary(model: SmdModel, out_path: str, model_name: str = "Mesh") -> None:
    """将 SMD 模型导出为 FBX 二进制文件（仅静态网格）。"""
    vertices: List[Vertex] = []
    for tri in model.triangles:
        vertices.append(tri.v0)
        vertices.append(tri.v1)
        vertices.append(tri.v2)

    verts_flat = []
    for v in vertices:
        verts_flat.extend([v.x, v.y, v.z])
    norms_flat = []
    for v in vertices:
        norms_flat.extend([v.nx, v.ny, v.nz])
    uv_flat = []
    for v in vertices:
        uv_flat.extend([v.u, v.v])

    poly_indices = []
    for i in range(0, len(vertices), 3):
        poly_indices.append(i)
        poly_indices.append(i + 1)
        poly_indices.append(-(i + 3))  # FBX 用负数表示多边形结束

    safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in model_name)
    geom_name = safe_name
    model_node_name = safe_name

    # 构建节点树（与常见 FBX 结构一致，便于 Unity 识别）
    # LayerElementNormal 子节点
    le_normal_props = [
        _prop_i(101),
        _prop_s(""),
        _prop_s("ByPolygonVertex"),
        _prop_s("Direct"),
        _prop_f_array(norms_flat),
    ]
    # LayerElementUV 子节点
    le_uv_props = [
        _prop_i(101),
        _prop_s("UVMap"),
        _prop_s("ByPolygonVertex"),
        _prop_s("Direct"),
        _prop_f_array(uv_flat),
    ]
    # Geometry 节点
    geom_children = [
        ("LayerElementNormal", le_normal_props, []),
        ("LayerElementUV", le_uv_props, []),
    ]
    geom_props = [
        _prop_s(geom_name),
        _prop_s("Mesh"),
        _prop_f_array(verts_flat),
        _prop_i_array(poly_indices),
        _prop_i(124),
    ]
    # Model 节点
    model_props = [
        _prop_s(model_node_name),
        _prop_s("Mesh"),
        _prop_i(232),
    ]

    objects_children = [
        ("Geometry", geom_props, geom_children),
        ("Model", model_props, []),
    ]
    objects_props = []
    objects_node = ("Objects", objects_props, objects_children)

    # Connections: OO Model::name Geometry::name
    conn_props = [
        _prop_s("OO"),
        _prop_s("Model::" + model_node_name),
        _prop_s("Geometry::" + geom_name),
    ]
    connections_node = ("Connections", conn_props, [])

    # Definitions
    def_geom_props = [_prop_i(100), _prop_s("Geometry"), _prop_s(""), _prop_s(""), _prop_i(1)]
    def_model_props = [_prop_i(100), _prop_s("Model"), _prop_s(""), _prop_s(""), _prop_i(1)]
    definitions_children = [
        ("ObjectType", def_geom_props, []),
        ("ObjectType", def_model_props, []),
    ]
    definitions_node = ("Definitions", [_prop_i(100)], definitions_children)

    # FBXHeaderExtension
    header_ext_children = [
        ("FBXHeaderVersion", [_prop_i(1003)], []),
        ("FBXVersion", [_prop_i(FBX_VERSION)], []),
        ("Creator", [_prop_s("SMD to FBX Binary")], []),
    ]
    header_ext_node = ("FBXHeaderExtension", [], header_ext_children)

    # Unity 等导入器常要求存在 GlobalSettings（版本/单位等）
    global_settings_children = [
        ("Version", [_prop_i(1000)], []),
    ]
    global_settings_node = ("GlobalSettings", [], global_settings_children)

    root_children = [
        header_ext_node,
        global_settings_node,
        definitions_node,
        objects_node,
        connections_node,
    ]

    buf = BytesIO()
    # 文件头 27 字节
    buf.write(HEADER_MAGIC)
    buf.write(bytes([0x1A, 0x00]))  # 固定
    buf.write(struct.pack("<I", FBX_VERSION))

    # 根节点：空名、0 属性、包含上述子节点
    _write_node(buf, "", [], root_children)

    with open(out_path, "wb") as f:
        f.write(buf.getvalue())
