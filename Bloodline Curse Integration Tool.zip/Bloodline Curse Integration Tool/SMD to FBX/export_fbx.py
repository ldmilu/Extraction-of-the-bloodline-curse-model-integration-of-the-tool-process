# -*- coding: utf-8 -*-
"""将 SmdModel 导出为 FBX ASCII（静态网格）"""
from typing import List
from smd_parser import SmdModel, Vertex


def write_fbx(model: SmdModel, out_path: str, model_name: str = "Mesh") -> None:
    """
    将 SMD 模型导出为 FBX ASCII 文件（仅静态网格，无骨骼动画）。
    部分 3D 软件对 ASCII FBX 支持有限，若无法打开可改用 OBJ 或先用 Blender 转成二进制 FBX。
    """
    vertices: List[Vertex] = []
    for tri in model.triangles:
        vertices.append(tri.v0)
        vertices.append(tri.v1)
        vertices.append(tri.v2)

    verts_str = ",".join(f"{v.x},{v.y},{v.z}" for v in vertices)
    norms_str = ",".join(f"{v.nx},{v.ny},{v.nz}" for v in vertices)
    uv_str = ",".join(f"{v.u},{v.v}" for v in vertices)

    # 三角形索引：每三个顶点一个三角形，FBX 用负号表示多边形结束
    # PolygonVertexIndex: i0, i1, -i2, i3, i4, -i5, ... (索引从 0 开始，结束索引写为 -(i+1))
    poly_indices: List[str] = []
    for i in range(0, len(vertices), 3):
        poly_indices.append(str(i))
        poly_indices.append(str(i + 1))
        poly_indices.append(str(-(i + 2 + 1)))  # -((i+2)+1) 表示第三个顶点并结束
    poly_str = ",".join(poly_indices)

    safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in model_name)
    content = f"""; FBX 7.4.0 project file
FBXHeaderExtension:  {{
	FBXHeaderVersion: 1003
	FBXVersion: 7400
	Creator: "SMD to FBX converter"
}}

Definitions:  {{
	Version: 100
	ObjectType: "Geometry" {{
		Count: 1
	}}
}}

Objects:  {{
	Model: "{safe_name}", "Mesh" {{
		Version: 232
		Vertices: {verts_str}
		PolygonVertexIndex: {poly_str}
		GeometryVersion: 124
		LayerElementNormal:  {{
			Version: 101
			Name: ""
			MappingInformationType: "ByPolygonVertex"
			ReferenceInformationType: "Direct"
			Normals: {norms_str}
		}}
		LayerElementUV:  {{
			Version: 101
			Name: "UVMap"
			MappingInformationType: "ByPolygonVertex"
			ReferenceInformationType: "Direct"
			UV: {uv_str}
		}}
		Shading: Y
		Culling: "CullingOff"
	}}
}}

"""
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)
