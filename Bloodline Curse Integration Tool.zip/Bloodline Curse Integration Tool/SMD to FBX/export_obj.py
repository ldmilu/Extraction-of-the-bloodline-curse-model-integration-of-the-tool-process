# -*- coding: utf-8 -*-
"""将 SmdModel 导出为 OBJ（及 MTL）"""
from typing import List, Optional
from smd_parser import SmdModel, Vertex


def write_obj(model: SmdModel, out_path: str, mtl_name: Optional[str] = None) -> None:
    """
    将 SMD 模型导出为 OBJ 文件。
    若存在材质则生成同名的 .mtl 文件。
    """
    mtl_name = mtl_name or "material"
    vertices: List[Vertex] = []
    materials_used: set = set()

    for tri in model.triangles:
        materials_used.add(tri.material)
        vertices.append(tri.v0)
        vertices.append(tri.v1)
        vertices.append(tri.v2)

    base_name = out_path.rsplit(".", 1)[0] if "." in out_path else out_path
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("# OBJ exported from SMD\n")
        if materials_used:
            f.write(f"mtllib {mtl_name}.mtl\n")
        for v in vertices:
            f.write(f"v {v.x} {v.y} {v.z}\n")
        for v in vertices:
            f.write(f"vt {v.u} {v.v}\n")
        for v in vertices:
            f.write(f"vn {v.nx} {v.ny} {v.nz}\n")
        current_mtl = None
        idx = 0
        for tri in model.triangles:
            if tri.material != current_mtl:
                current_mtl = tri.material
                safe_mtl = "".join(c if c.isalnum() or c in "._-" else "_" for c in tri.material)
                f.write(f"usemtl {safe_mtl}\n")
            i1, i2, i3 = idx + 1, idx + 2, idx + 3
            f.write(f"f {i1}/{i1}/{i1} {i2}/{i2}/{i2} {i3}/{i3}/{i3}\n")
            idx += 3

    if materials_used:
        mtl_path = base_name + ".mtl"
        with open(mtl_path, "w", encoding="utf-8") as m:
            m.write("# MTL for SMD export\n")
            for mat in materials_used:
                safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in mat)
                m.write(f"newmtl {safe}\n")
                m.write("Ka 0.2 0.2 0.2\n")
                m.write("Kd 0.8 0.8 0.8\n")
                m.write("Ks 0.1 0.1 0.1\n")
                m.write("Ns 10\n\n")
