# -*- coding: utf-8 -*-
"""
SMD 转 OBJ/FBX 转换脚本

用于命令行与启动脚本对接：
- 默认导出 OBJ（兼容旧用法）
- 支持 `--format fbx` 导出 FBX（二进制静态网格）
"""

import argparse
import os
import sys


def _normalize_output_path(output: str, ext: str) -> str:
    """
    将输出路径规范化到对应扩展名。
    如果 output 已经以 ext 结尾则原样返回，否则替换扩展名。
    """
    output = output.strip()
    low = output.lower()
    if low.endswith(ext.lower()):
        return output
    root, _old = os.path.splitext(output)
    return f"{root}{ext}"


def main():
    parser = argparse.ArgumentParser(
        description="将 SMD 模型转换为 OBJ/FBX 格式",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 导出 OBJ（默认）
  python smd_to_fbx.py model.smd
  python smd_to_fbx.py model.smd -o model.obj

  # 导出 FBX（二进制）
  python smd_to_fbx.py model.smd --format fbx
  python smd_to_fbx.py model.smd --format fbx -o model.fbx

  # 指定输出目录
  python smd_to_fbx.py model.smd --format fbx --out-dir D:\\out
        """,
    )
    parser.add_argument("input", help="输入的 .smd 文件路径")
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="输出文件路径（不指定则根据输入文件名和格式自动生成；建议单一格式时使用）",
    )
    parser.add_argument(
        "--out-dir",
        default=None,
        help="输出目录（不指定则使用输入文件所在目录）",
    )
    parser.add_argument(
        "--format",
        default="obj",
        choices=["obj", "fbx", "both"],
        help="输出格式：obj / fbx / both（默认 obj）",
    )
    parser.add_argument(
        "--fbx-kind",
        default="binary",
        choices=["binary", "ascii"],
        help="FBX 类型：binary（默认）/ ascii（仅部分软件支持 ASCII FBX）",
    )
    args = parser.parse_args()

    if not os.path.isfile(args.input):
        print(f"错误：找不到输入文件 '{args.input}'", file=sys.stderr)
        sys.exit(1)

    input_path = args.input
    base = os.path.splitext(os.path.basename(input_path))[0]
    in_dir = os.path.dirname(os.path.abspath(input_path))
    out_dir = args.out_dir or in_dir

    os.makedirs(out_dir, exist_ok=True)

    try:
        from smd_parser import parse_smd_file
        from export_obj import write_obj
        from obj_to_fbx_assimp import export_obj_to_fbx, HAS_PYASSIMP
        from export_fbx_binary import write_fbx_binary
        from export_fbx import write_fbx
    except ImportError:
        # 若作为包安装则用包名
        from smd_to_fbx.smd_parser import parse_smd_file
        from smd_to_fbx.export_obj import write_obj
        from smd_to_fbx.obj_to_fbx_assimp import export_obj_to_fbx, HAS_PYASSIMP
        from smd_to_fbx.export_fbx_binary import write_fbx_binary
        from smd_to_fbx.export_fbx import write_fbx

    print(f"正在解析: {input_path}")
    model = parse_smd_file(input_path)
    tri_count = len(model.triangles)
    print(f"  三角形数: {tri_count}")
    if tri_count == 0:
        print("警告：未找到三角形数据，请确认 SMD 包含 triangles 块。", file=sys.stderr)

    formats = [args.format] if args.format != "both" else ["obj", "fbx"]

    if args.format == "both" and args.output:
        print("错误：当 --format=both 时，请不要使用 -o/--output（请改用 --out-dir）。", file=sys.stderr)
        sys.exit(2)

    # 导出 OBJ
    if "obj" in formats:
        obj_path = (
            _normalize_output_path(args.output, ".obj")
            if (args.output and args.format == "obj")
            else os.path.join(out_dir, base + ".obj")
        )
        write_obj(model, obj_path)
        print(f"已导出 OBJ: {obj_path}")

    # 导出 FBX
    if "fbx" in formats:
        ext = ".fbx"
        fbx_path = (
            _normalize_output_path(args.output, ext)
            if (args.output and args.format == "fbx")
            else os.path.join(out_dir, base + ext)
        )

        # 采用 OBJ -> FBX（Assimp/PyAssimp）导出，和工具箱拖放窗口一致
        # 注意：即使用户选择 fbx-kind=ascii，这里也优先导出“可用的 FBX”，并用文件名区分来源。
        obj_tmp = os.path.join(out_dir, f"{base}__tmp.obj")
        mtl_tmp = os.path.join(out_dir, f"{base}__tmp.mtl")
        write_obj(model, obj_tmp)

        if HAS_PYASSIMP and export_obj_to_fbx(obj_tmp, fbx_path):
            print(f"已导出 FBX（Assimp）：{fbx_path}")
        else:
            # 兜底：保持旧行为，尽量导出某种 FBX（但可能与目标软件兼容性不同）
            if not HAS_PYASSIMP:
                print("警告：未检测到 pyassimp/Assimp，使用 fallback 导出器。")
            else:
                print("警告：Assimp 导出失败，使用 fallback 导出器。")
            if args.fbx_kind == "binary":
                write_fbx_binary(model, fbx_path)
            else:
                write_fbx(model, fbx_path)
            print(f"已导出 FBX（fallback）：{fbx_path}")

        # 清理临时 OBJ/MTL
        try:
            if os.path.isfile(obj_tmp):
                os.remove(obj_tmp)
            if os.path.isfile(mtl_tmp):
                os.remove(mtl_tmp)
        except OSError:
            pass

    print("完成。")


if __name__ == "__main__":
    main()
