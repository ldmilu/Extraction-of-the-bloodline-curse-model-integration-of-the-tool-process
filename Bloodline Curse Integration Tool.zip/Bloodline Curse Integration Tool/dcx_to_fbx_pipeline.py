# -*- coding: utf-8 -*-
"""
dcx -> flver -> (smd + ascii) -> fbx

目标：
- 支持把多个 .dcx 文件拖进来批量处理
- 在“flver -> smd + ascii”阶段把 ascii 单独另存到你指定的文件夹
- 最终导出 FBX（默认 binary）

依赖：
- 你的系统已装好 Python（项目内现有脚本都是用内置 Python）
- 需要外部工具：
  - Yabber.DCX.exe（dcx 解压/解压缩）
  - BloodBorne_model_v3.exe（flver -> smd + ascii）
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
import shutil
from pathlib import Path
from typing import Iterable, Optional


def _hide_tk_root():
    import tkinter as tk

    root = tk.Tk()
    root.withdraw()
    root.update()
    return root


def _ask_open_file(title: str, filetypes: list[tuple[str, str]]):
    import tkinter as tk
    from tkinter import filedialog

    _hide_tk_root()
    path = filedialog.askopenfilename(title=title, filetypes=filetypes)
    if not path:
        raise RuntimeError(f"未选择：{title}")
    return Path(path)


def _ask_select_dir(title: str):
    from tkinter import filedialog

    _hide_tk_root()
    path = filedialog.askdirectory(title=title)
    if not path:
        raise RuntimeError(f"未选择目录：{title}")
    return Path(path)


def _ask_open_files(title: str, filetypes: list[tuple[str, str]]) -> list[Path]:
    """选择多个文件（对话框返回空则为 []）。"""
    import tkinter as tk
    from tkinter import filedialog

    _hide_tk_root()
    paths = filedialog.askopenfilenames(title=title, filetypes=filetypes)
    if not paths:
        return []
    return [Path(p) for p in paths]


def _collect_dcx_inputs(paths: Iterable[Path], recursive: bool = False) -> list[Path]:
    out: list[Path] = []
    for p in paths:
        if p.is_dir():
            if recursive:
                out.extend(
                    [x for x in p.rglob("*") if x.is_file() and x.suffix.lower() == ".dcx"]
                )
            else:
                out.extend([x for x in p.iterdir() if x.is_file() and x.suffix.lower() == ".dcx"])
        elif p.is_file() and p.suffix.lower() == ".dcx":
            out.append(p)
    # 去重：按字符串路径去重保持顺序
    seen = set()
    deduped = []
    for p in out:
        s = str(p)
        if s not in seen:
            seen.add(s)
            deduped.append(p)
    return deduped


def _find_flver_after(dcx_path: Path, start_ts: float) -> Path:
    """
    Yabber.DCX.exe 在 dcx 同目录生成 .flver（通常同名）。
    做两段式查找：先找同名，再找 start_ts 之后生成的最可疑文件。
    """
    dcx_dir = dcx_path.parent

    # Yabber.DCX.exe 的常见行为：把 "...某后缀.dcx" 解压为 "...某后缀"
    # 例如：m22_....flver.dcx -> m22_....flver
    expected = dcx_path.with_suffix("")  # 去掉最后的 ".dcx"
    if expected.is_file():
        return expected

    expected_name_lower = expected.name.lower()
    expected_suffix_lower = expected.suffix.lower()  # 比如 ".flver"

    # start_ts 后新出现的“同名文件”优先
    candidates = [
        x
        for x in dcx_dir.iterdir()
        if x.is_file() and x.name.lower() == expected_name_lower and x.stat().st_mtime >= start_ts - 0.5
    ]
    if candidates:
        candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return candidates[0]

    # 否则：找 start_ts 后新增且后缀匹配 expected 的最新文件
    by_suffix = [
        x
        for x in dcx_dir.iterdir()
        if x.is_file()
        and x.suffix.lower() == expected_suffix_lower
        and x.stat().st_mtime >= start_ts - 0.5
    ]
    if by_suffix:
        by_suffix.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return by_suffix[0]

    raise FileNotFoundError(f"未找到由 Yabber 生成的 FLVER：{dcx_path}（预期：{expected.name}）")


def _iter_case_insensitive_matches(dir_path: Path, target_name_lower: str) -> list[Path]:
    if not dir_path.is_dir():
        return []
    res: list[Path] = []
    for p in dir_path.iterdir():
        if p.is_file() and p.name.lower() == target_name_lower:
            res.append(p)
    return res


def _find_files_by_stem_and_ext(dir_path: Path, stem: str, ext: str) -> list[Path]:
    """按“文件名包含 stem 且以 ext 结尾”方式找（忽略大小写）。"""
    if not dir_path.is_dir():
        return []
    ext_norm = ext.lower()
    if not ext_norm.startswith("."):
        ext_norm = "." + ext_norm
    stem_lower = stem.lower()
    res: list[Path] = []
    for p in dir_path.iterdir():
        if not p.is_file():
            continue
        name_lower = p.name.lower()
        if name_lower.startswith(stem_lower) and name_lower.endswith(ext_norm):
            res.append(p)
    return res


def _find_xml_outputs_after(dcx_dir: Path, start_ts: float, base_stem: str) -> list[Path]:
    """
    BloodBorne/Yabber.DCX 解压时通常会在 dcx 同目录生成一个 xml 文件（记录解压/重打包信息）。
    这里用“生成时间 >= start_ts - 0.5 且文件名包含 base_stem”来猜测对应 xml。
    """
    if not dcx_dir.is_dir():
        return []
    base_lower = base_stem.lower()
    res: list[Path] = []
    for p in dcx_dir.iterdir():
        if not p.is_file():
            continue
        if p.suffix.lower() != ".xml":
            continue
        if p.stat().st_mtime < start_ts - 0.5:
            continue
        if base_lower in p.name.lower():
            res.append(p)
    # 去重
    uniq = []
    seen = set()
    for p in res:
        s = str(p)
        if s not in seen:
            seen.add(s)
            uniq.append(p)
    return uniq


def load_tools(root_dir: Path):
    """加载本项目内的 python 工具函数/模块。"""
    bloodborne_dir = root_dir / "bloodborne"
    smd_tool_dir = root_dir / "SMD转FBX工具"

    # 为了兼容“从别的脚本 import 本脚本”场景，确保 sys.path 只插入一次
    if str(bloodborne_dir) not in sys.path:
        sys.path.insert(0, str(bloodborne_dir))
    if str(smd_tool_dir) not in sys.path:
        sys.path.insert(0, str(smd_tool_dir))

    import flver_to_smd_ascii as bb  # type: ignore
    from smd_parser import parse_smd_file  # type: ignore

    # 使用和 SMD 工具箱一致的导出方式：OBJ -> FBX（Assimp/PyAssimp）
    from export_obj import write_obj  # type: ignore
    from obj_to_fbx_assimp import export_obj_to_fbx, HAS_PYASSIMP  # type: ignore

    # 兜底：PyAssimp 不可用时仍尝试用旧导出器
    from export_fbx_binary import write_fbx_binary  # type: ignore
    from export_fbx import write_fbx  # type: ignore

    return bb, parse_smd_file, write_obj, export_obj_to_fbx, HAS_PYASSIMP, write_fbx_binary, write_fbx


def convert_one_dcx(
    dcx: Path,
    *,
    yb_exe: Path,
    bloodborne_exe: Path,
    fbx_dir: Path,
    smd_dir: Path,
    ascii_dir: Path,
    fbx_kinds: list[str],
    skip_existing: bool,
    keep_smd: bool = True,
    keep_ascii: bool = True,
    keep_flver: bool = False,
    keep_xml: bool = False,
    tools,
    log,
) -> bool:
    """
    处理单个 dcx：
    1) Yabber.DCX.exe: dcx -> flver
    2) BloodBorne_model_v3.exe: flver -> smd + ascii（先都到 smd_dir）
    3) 把 ascii 再迁移到 ascii_dir
    4) smd -> fbx（默认 binary，ascii/both 按选项）
    """
    bb, parse_smd_file, write_obj, export_obj_to_fbx, HAS_PYASSIMP, write_fbx_binary, write_fbx = tools
    start_ts = time.time()
    total_expected_fbx = []
    try:
        log(f"  [1/4] dcx -> flver：{dcx.name}")
        subprocess.run([str(yb_exe), str(dcx)], check=True)
        flver_path = _find_flver_after(dcx, start_ts=start_ts)
        base_stem = flver_path.stem  # 关键：xxx.flver.dcx -> flver_path.stem 为 xxx（不含 .flver）
        log(f"  [2/4] flver：{flver_path.name} （base={base_stem}）")

        # flver -> smd + ascii（输出先进入 smd_dir）
        bb.run_converter(bloodborne_exe, flver_path)
        bb.move_outputs(flver_path, smd_dir)

        # 迁移 ascii 到单独目录
        log(f"  [3/4] 迁移 ascii：{base_stem}")
        ascii_files = _find_files_by_stem_and_ext(smd_dir, base_stem, ".ascii")
        if not ascii_files:
            # 做一个更直观的诊断：列出 smd_dir 下与 stem 相关的文件
            related = []
            for p in smd_dir.iterdir():
                if p.is_file() and p.name.lower().startswith(base_stem.lower()):
                    related.append(p.name)
            related.sort()
            log(f"    警告：未在 SMD 目录找到 {base_stem}.ascii（related={related}）")
        if keep_ascii:
            ascii_dir.mkdir(parents=True, exist_ok=True)
            for af in ascii_files:
                target = ascii_dir / af.name
                shutil.move(str(af), str(target))
                log(f"    ascii：{af.name} -> {target}")
        else:
            for af in ascii_files:
                try:
                    af.unlink()
                    log(f"    清理 ASCII：已删除 {af.name}")
                except OSError:
                    log(f"    清理 ASCII：删除失败 {af.name}")

        # 导出 FBX：查找 smd
        log(f"  [4/4] smd -> fbx：{base_stem}")
        smd_files = _find_files_by_stem_and_ext(smd_dir, base_stem, ".smd")
        if not smd_files:
            related = []
            for p in smd_dir.iterdir():
                if p.is_file() and p.name.lower().startswith(base_stem.lower()):
                    related.append(p.name)
            related.sort()
            raise FileNotFoundError(f"未在 SMD 目录找到 {base_stem}.smd（related={related}）")

        # 取最新的一个（同 stem 理论上只会有一个）
        smd_path = sorted(smd_files, key=lambda p: p.stat().st_mtime, reverse=True)[0]
        log(f"    使用 smd：{smd_path.name}")

        model = parse_smd_file(str(smd_path))

        # 统一使用 OBJ -> FBX 导出（更符合你工具箱的“可用 FBX”结果）
        # both 时：
        # - binary:  xxx.fbx
        # - ascii:   xxx_ascii.fbx（仅区分来源命名，不强制导出 ASCII FBX 格式）
        for kind in fbx_kinds:
            if kind == "binary":
                fbx_path = fbx_dir / f"{base_stem}.fbx"
            else:
                fbx_path = fbx_dir / f"{base_stem}_ascii.fbx"

            total_expected_fbx.append(fbx_path)
            if skip_existing and fbx_path.exists():
                log(f"    FBX：已存在，跳过 {fbx_path.name}")
                continue

            # 写临时 OBJ
            obj_tmp = fbx_dir / f"{base_stem}__tmp.obj"
            mtl_tmp = fbx_dir / f"{base_stem}__tmp.mtl"
            write_obj(model, str(obj_tmp))

            if HAS_PYASSIMP and export_obj_to_fbx(str(obj_tmp), str(fbx_path)):
                log(f"    FBX(Assimp)：{fbx_path.name}")
            else:
                # 兜底：仍用自带导出器（可能不如 Assimp 兼容）
                if not HAS_PYASSIMP:
                    log("    警告：未检测到 pyassimp/Assimp，FBX 可能与目标软件不兼容。")
                else:
                    log("    警告：Assimp 导出失败，正在使用 fallback 导出器。")
                if kind == "binary":
                    write_fbx_binary(model, str(fbx_path))
                else:
                    write_fbx(model, str(fbx_path))
                log(f"    FBX(fallback)：{fbx_path.name}")

            # 清理临时 OBJ/MTL
            try:
                if obj_tmp.exists():
                    obj_tmp.unlink()
                if mtl_tmp.exists():
                    mtl_tmp.unlink()
            except OSError:
                pass

        # 根据选择清理中间文件（先处理 flver/xml，再处理 smd/ascii）
        if keep_flver or keep_xml:
            # flver_path 与 xml 都已经不再被使用（因为 BB 转换已完成并且输出已搬走）
            pass

        # flver/xml：搬到独立目录 或删除
        flver_xml_dir: Path | None = None
        if keep_flver or keep_xml:
            flver_xml_dir = fbx_dir / "flver_xml"
            flver_xml_dir.mkdir(parents=True, exist_ok=True)

        # flver：搬到 flver_xml 目录 或删除
        if keep_flver:
            assert flver_xml_dir is not None
            dst = flver_xml_dir / flver_path.name
            if dst.exists():
                # 避免覆盖（同名极少发生，但这里稳一点）
                ts = int(time.time())
                dst = flver_xml_dir / f"{flver_path.stem}_{ts}{flver_path.suffix}"
            shutil.move(str(flver_path), str(dst))
            log(f"    保留 FLVER：{flver_path.name} -> {dst.name}")
        else:
            try:
                if flver_path.is_file():
                    flver_path.unlink()
                    log(f"    清理 FLVER：已删除 {flver_path.name}")
            except OSError:
                log(f"    清理 FLVER：删除失败 {flver_path.name}")

        # xml：搬到 flver_xml 目录 或删除
        xml_paths = _find_xml_outputs_after(dcx_dir=dcx.parent, start_ts=start_ts, base_stem=base_stem)
        for xp in xml_paths:
            if keep_xml:
                assert flver_xml_dir is not None
                dst = flver_xml_dir / xp.name
                if dst.exists():
                    ts = int(time.time())
                    dst = flver_xml_dir / f"{xp.stem}_{ts}{xp.suffix}"
                shutil.move(str(xp), str(dst))
                log(f"    保留 XML：{xp.name} -> {dst.name}")
            else:
                try:
                    if xp.is_file():
                        xp.unlink()
                        log(f"    清理 XML：已删除 {xp.name}")
                except OSError:
                    log(f"    清理 XML：删除失败 {xp.name}")

        # 然后根据选择清理 smd/ascii（这些已经移动到 smd_dir/ascii_dir，或已在前面删除）
        if not keep_ascii:
            if ascii_dir.exists() and ascii_dir.is_dir():
                ascii_to_delete = _find_files_by_stem_and_ext(ascii_dir, base_stem, ".ascii")
                for af in ascii_to_delete:
                    try:
                        af.unlink()
                        log(f"    清理 ASCII：已删除 {af.name}")
                    except OSError:
                        log(f"    清理 ASCII：删除失败 {af.name}")
        if not keep_smd:
            smd_to_delete = _find_files_by_stem_and_ext(smd_dir, base_stem, ".smd")
            for sf in smd_to_delete:
                try:
                    sf.unlink()
                    log(f"    清理 SMD：已删除 {sf.name}")
                except OSError:
                    log(f"    清理 SMD：删除失败 {sf.name}")

            # 若 smd_dir 是临时目录（或空目录），尝试删除目录本身
            try:
                if smd_dir.exists() and smd_dir.is_dir():
                    # 只有当目录为空时才删除，避免误删其它模型
                    if not any(smd_dir.iterdir()):
                        smd_dir.rmdir()
                        log(f"    清理 SMD 目录：已删除 {smd_dir}")
            except OSError:
                pass

        # ascii_dir 也尝试清理空目录（仅在目录实际存在时）
        if not keep_ascii:
            try:
                if ascii_dir.exists() and ascii_dir.is_dir() and not any(ascii_dir.iterdir()):
                    ascii_dir.rmdir()
                    log(f"    清理 ASCII 目录：已删除 {ascii_dir}")
            except OSError:
                pass

        return True
    except Exception as e:  # noqa: BLE001
        log(f"  失败：{dcx.name}\n    {e}")
        return False


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="批量把 dcx 转为 FBX：Yabber.DCX -> BloodBorne_model_v3 -> (SMD->FBX)",
    )
    parser.add_argument("inputs", nargs="*", help="拖入的 .dcx 文件或文件夹（将递归收集 .dcx）")
    parser.add_argument("--yabber-exe", type=Path, default=None, help="Yabber.DCX.exe 路径")
    parser.add_argument("--bloodborne-exe", type=Path, default=None, help="BloodBorne_model_v3.exe 路径")
    parser.add_argument("--fbx-dir", type=Path, default=None, help="FBX 输出目录")
    parser.add_argument("--smd-dir", type=Path, default=None, help="SMD 输出目录（默认：fbx-dir/smd）")
    parser.add_argument("--ascii-dir", type=Path, default=None, help="ASCII 输出目录（默认：fbx-dir/ascii）")
    parser.add_argument(
        "--fbx-kind",
        default="binary",
        choices=["binary", "ascii", "both"],
        help="输出 FBX 类型：binary / ascii / both",
    )
    parser.add_argument("--skip-existing", action="store_true", help="如果目标 FBX 已存在则跳过")
    args = parser.parse_args(argv)

    input_paths = [Path(x) for x in args.inputs]
    dcx_paths = _collect_dcx_inputs(input_paths)
    if not dcx_paths:
        # 双击启动 bat 时通常没有参数：给用户选择入口
        try:
            dcx_paths = _ask_open_files("选择 .dcx 文件（可多选）", [("DCX 文件", "*.dcx"), ("所有文件", "*.*")])
            if not dcx_paths:
                dir_path = _ask_select_dir("未选择 .dcx 文件：请选择包含 .dcx 的文件夹（将递归收集）")
                dcx_paths = _collect_dcx_inputs([dir_path])
        except Exception as e:  # noqa: BLE001
            print(f"未选择输入：{e}", file=sys.stderr)
            return 2

    if not dcx_paths:
        print("未找到输入 .dcx 文件。", file=sys.stderr)
        return 2

    script_dir = Path(__file__).resolve().parent
    root_dir = script_dir

    try:
        tools = load_tools(root_dir)
    except Exception as e:  # noqa: BLE001
        print(f"导入失败：{e}", file=sys.stderr)
        return 1

    # 选择外部 exe
    if args.yabber_exe is None:
        args.yabber_exe = _ask_open_file("选择 Yabber.DCX.exe", [("可执行文件", "*.exe"), ("所有文件", "*.*")])
    if args.bloodborne_exe is None:
        args.bloodborne_exe = _ask_open_file(
            "选择 BloodBorne_model_v3.exe（或兼容的 BloodBorne_model.exe）",
            [("可执行文件", "*.exe"), ("所有文件", "*.*")],
        )
    if not args.yabber_exe.is_file():
        print(f"找不到 Yabber.DCX.exe：{args.yabber_exe}", file=sys.stderr)
        return 1
    if not args.bloodborne_exe.is_file():
        print(f"找不到 BloodBorne_model.exe：{args.bloodborne_exe}", file=sys.stderr)
        return 1

    # 选择输出目录
    if args.fbx_dir is None:
        args.fbx_dir = _ask_select_dir("选择 FBX 输出目录")
    if args.smd_dir is None:
        args.smd_dir = args.fbx_dir / "smd"
    if args.ascii_dir is None:
        args.ascii_dir = args.fbx_dir / "ascii"

    args.fbx_dir.mkdir(parents=True, exist_ok=True)
    args.smd_dir.mkdir(parents=True, exist_ok=True)
    args.ascii_dir.mkdir(parents=True, exist_ok=True)

    fbx_kinds = ["binary"] if args.fbx_kind == "binary" else (["ascii"] if args.fbx_kind == "ascii" else ["binary", "ascii"])

    ok = 0
    total = len(dcx_paths)

    for idx, dcx in enumerate(dcx_paths, start=1):
        print(f"[{idx}/{total}] 处理：{dcx}")

        def _log(s: str):
            print(s)

        if convert_one_dcx(
            dcx,
            yb_exe=args.yabber_exe,
            bloodborne_exe=args.bloodborne_exe,
            fbx_dir=args.fbx_dir,
            smd_dir=args.smd_dir,
            ascii_dir=args.ascii_dir,
            fbx_kinds=fbx_kinds,
            skip_existing=args.skip_existing,
            tools=tools,
            log=_log,
        ):
            ok += 1

    print(f"全部完成：成功 {ok} / {total}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())

