@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem 双击：打开可视化窗口；拖入：走命令行批处理管线
set "DIR=%~dp0"
if "%~1"=="" goto :gui
goto :pipeline

:gui
python "%DIR%dcx_to_fbx_gui.py"
pause
exit /b %errorlevel%

:pipeline
rem 拖入多个 .dcx（支持拖入文件夹：在 python 脚本里递归收集）
python "%DIR%dcx_to_fbx_pipeline.py" %*
if %errorlevel% neq 0 pause
exit /b %errorlevel%

