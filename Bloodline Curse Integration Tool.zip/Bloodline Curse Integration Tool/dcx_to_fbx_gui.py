# -*- coding: utf-8 -*-
"""
dcx -> FBX GUI

Features:
- Select multiple .dcx files or a folder (collects .dcx)
- Pick Yabber.DCX.exe and BloodBorne_model_v3.exe
- Pick output directory (FBX / SMD / ASCII separated)
- Log output in the window
"""

from __future__ import annotations

import json
import sys
import threading
import shutil
from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter.scrolledtext import ScrolledText


def _build_log_widget(root: tk.Tk):
    log = ScrolledText(root, height=14, state=tk.DISABLED, font=("Consolas", 9))
    log.pack(fill=tk.BOTH, expand=True, padx=12, pady=(6, 12))
    return log


def _append_log(root: tk.Tk, log: ScrolledText, msg: str):
    def _inner():
        log.configure(state=tk.NORMAL)
        log.insert(tk.END, msg + "\n")
        log.see(tk.END)
        log.configure(state=tk.DISABLED)

    root.after(0, _inner)


def main(argv: Optional[list[str]] = None) -> int:
    from dcx_to_fbx_pipeline import convert_one_dcx, load_tools, _collect_dcx_inputs

    script_dir = Path(__file__).resolve().parent
    state_file = script_dir / "dcx_to_fbx_gui_state.json"

    def load_state():
        if not state_file.exists():
            return {}
        try:
            return json.loads(state_file.read_text(encoding="utf-8"))
        except Exception:
            return {}

    state = load_state()

    # 允许用拖入参数预填：bat 传参时 sys.argv 会包含 dcx 路径
    initial_inputs = []
    if argv is None:
        argv = sys.argv[1:]
    for a in argv:
        p = Path(a)
        if p.exists():
            initial_inputs.append(p)

    root = tk.Tk()
    root.title("dcx -> flver -> smd+ascii -> fbx (batch)")
    root.geometry("900x620")

    dcx_list: list[Path] = []
    yabber_exe: Optional[Path] = None
    bloodborne_exe: Optional[Path] = None
    out_dir: Optional[Path] = None

    fbx_kind_var = tk.StringVar(value="binary")
    skip_existing_var = tk.BooleanVar(value=False)
    keep_smd_var = tk.BooleanVar(value=bool(state.get("keep_smd", False)))
    keep_ascii_var = tk.BooleanVar(value=bool(state.get("keep_ascii", False)))
    keep_flver_var = tk.BooleanVar(value=bool(state.get("keep_flver", False)))
    keep_xml_var = tk.BooleanVar(value=bool(state.get("keep_xml", False)))

    def set_state_path(key: str, value: Optional[Path]):
        state[key] = str(value) if value is not None else None

    top = tk.Frame(root)
    top.pack(fill=tk.X, padx=12, pady=(12, 6))

    tk.Button(
        top,
        text="Select .dcx files (multi-select)",
        command=lambda: None,
    ).pack(side=tk.LEFT)

    # 由于需要多个按钮自定义回调，用变量引用先声明再绑定
    def on_choose_inputs():
        paths_files = filedialog.askopenfilenames(
            title="Select .dcx files",
            filetypes=[("DCX files", "*.dcx"), ("All files", "*.*")],
        )
        chosen = [Path(x) for x in paths_files]
        if not chosen:
            return

        dcx_list.clear()
        # 这里把“文件/文件夹”都先暂存，真正递归收集在开始时做
        dcx_list.extend(chosen)
        refresh_listbox()

    def on_choose_folder_only():
        d = filedialog.askdirectory(title="Select folder containing .dcx files")
        if not d:
            return
        dcx_list.clear()
        dcx_list.append(Path(d))
        refresh_listbox()

    def refresh_listbox():
        listbox.delete(0, tk.END)
        if not dcx_list:
            listbox.insert(tk.END, "(none selected)")
            return
        for p in dcx_list:
            listbox.insert(tk.END, str(p))

    def on_choose_yabber():
        nonlocal yabber_exe
        p = filedialog.askopenfilename(title="Select Yabber.DCX.exe", filetypes=[("Executables", "*.exe"), ("All files", "*.*")])
        if p:
            yabber_exe = Path(p)
            set_state_path("yabber_exe", yabber_exe)
            yabber_path_lbl.configure(text=str(yabber_exe))
            _append_log(root, log, f"Yabber: {yabber_exe}")

    def on_choose_bloodborne():
        nonlocal bloodborne_exe
        p = filedialog.askopenfilename(
            title="Select BloodBorne_model_v3.exe",
            filetypes=[("Executables", "*.exe"), ("All files", "*.*")],
        )
        if p:
            bloodborne_exe = Path(p)
            set_state_path("bloodborne_exe", bloodborne_exe)
            bloodborne_path_lbl.configure(text=str(bloodborne_exe))
            _append_log(root, log, f"BloodBorne_model: {bloodborne_exe}")

    def on_choose_outdir():
        nonlocal out_dir
        p = filedialog.askdirectory(
            title="Select output folder (creates smd/ and ascii/; optional flver/xml in root per options)",
        )
        if p:
            out_dir = Path(p)
            set_state_path("out_dir", out_dir)
            out_path_lbl.configure(text=str(out_dir))
            _append_log(root, log, f"Output folder: {out_dir}")

    # 重新给按钮绑定回调
    top_children = top.winfo_children()
    if top_children:
        # 第一个是选择输入按钮
        top_children[0].configure(command=on_choose_inputs)

    tk.Button(
        top,
        text="Select folder with .dcx",
        command=on_choose_folder_only,
    ).pack(side=tk.LEFT, padx=(8, 0))

    row2 = tk.Frame(root)
    row2.pack(fill=tk.X, padx=12, pady=(0, 6))

    tk.Button(row2, text="Yabber.DCX.exe…", command=on_choose_yabber).pack(side=tk.LEFT, padx=(0, 8))
    tk.Button(row2, text="BloodBorne_model_v3.exe…", command=on_choose_bloodborne).pack(side=tk.LEFT, padx=(0, 8))

    row3 = tk.Frame(root)
    row3.pack(fill=tk.X, padx=12, pady=(0, 6))

    tk.Button(row3, text="Output folder…", command=on_choose_outdir).pack(side=tk.LEFT, padx=(0, 8))

    tk.Label(row3, text="FBX kind:").pack(side=tk.LEFT)
    tk.OptionMenu(row3, fbx_kind_var, "binary", "ascii", "both").pack(side=tk.LEFT, padx=(6, 18))

    tk.Checkbutton(row3, text="Skip existing FBX", variable=skip_existing_var).pack(side=tk.LEFT)

    row4 = tk.Frame(root)
    row4.pack(fill=tk.X, padx=12, pady=(0, 6))
    tk.Checkbutton(row4, text="Keep SMD (debug)", variable=keep_smd_var).pack(side=tk.LEFT, padx=(0, 18))
    tk.Checkbutton(row4, text="Keep ASCII (debug)", variable=keep_ascii_var).pack(side=tk.LEFT, padx=(0, 18))
    tk.Checkbutton(row4, text="Keep FLVER (debug)", variable=keep_flver_var).pack(side=tk.LEFT, padx=(0, 18))
    tk.Checkbutton(row4, text="Keep XML (debug)", variable=keep_xml_var).pack(side=tk.LEFT, padx=(0, 18))

    # 路径显示区：下次打开可直接看到上次选择
    path_area = tk.Frame(root)
    path_area.pack(fill=tk.X, padx=12, pady=(0, 2))
    tk.Label(path_area, text="Yabber.DCX.exe:").pack(side=tk.LEFT)
    yabber_path_lbl = tk.Label(path_area, text="(none selected)", anchor="w")
    yabber_path_lbl.pack(side=tk.LEFT, fill=tk.X, expand=True)
    tk.Label(path_area, text="BloodBorne_model_v3.exe:").pack(side=tk.LEFT, padx=(12, 6))
    bloodborne_path_lbl = tk.Label(path_area, text="(none selected)", anchor="w")
    bloodborne_path_lbl.pack(side=tk.LEFT, fill=tk.X, expand=True)

    row_out = tk.Frame(root)
    row_out.pack(fill=tk.X, padx=12, pady=(0, 2))
    tk.Label(row_out, text="Output folder:").pack(side=tk.LEFT)
    out_path_lbl = tk.Label(row_out, text="(none selected)", anchor="w")
    out_path_lbl.pack(side=tk.LEFT, fill=tk.X, expand=True)

    mid = tk.Frame(root)
    mid.pack(fill=tk.BOTH, expand=False, padx=12, pady=(6, 0))

    tk.Label(
        mid,
        text="Input: files = only those .dcx; folder = .dcx in that folder (non-recursive).",
    ).pack(anchor="w")
    listbox = tk.Listbox(mid, height=6, selectmode=tk.EXTENDED)
    listbox.pack(fill=tk.BOTH, expand=True, pady=(6, 10))

    listbox.insert(tk.END, "(none selected)")

    bottom = tk.Frame(root)
    bottom.pack(fill=tk.X, padx=12, pady=(0, 6))

    start_btn = tk.Button(bottom, text="Start", width=16)
    start_btn.pack(side=tk.LEFT)

    def on_start():
        nonlocal yabber_exe, bloodborne_exe, out_dir
        if not dcx_list:
            messagebox.showwarning("Notice", "Please select .dcx file(s) or a folder.")
            return
        if yabber_exe is None or not yabber_exe.is_file():
            messagebox.showwarning("Notice", "Please select Yabber.DCX.exe.")
            return
        if bloodborne_exe is None or not bloodborne_exe.is_file():
            messagebox.showwarning("Notice", "Please select BloodBorne_model_v3.exe.")
            return
        if out_dir is None:
            messagebox.showwarning("Notice", "Please select an output folder.")
            return

        # 规则（按你的要求）：选文件 => 只处理这些 dcx；选文件夹 => 只处理该目录本级的 dcx（不递归子文件夹）
        dcx_paths = _collect_dcx_inputs(dcx_list, recursive=False)
        if not dcx_paths:
            messagebox.showwarning("Notice", "No .dcx inputs found.")
            return

        fbx_kind = fbx_kind_var.get()
        fbx_kinds = ["binary"] if fbx_kind == "binary" else (["ascii"] if fbx_kind == "ascii" else ["binary", "ascii"])

        keep_smd = bool(keep_smd_var.get())
        keep_ascii = bool(keep_ascii_var.get())

        # 不勾选时：不在输出根目录创建 smd/ascii 文件夹
        # 转换中间产物会落到临时目录并在结束后清理干净
        smd_dir = out_dir / ("smd" if keep_smd else "_tmp_smd")
        ascii_dir = out_dir / ("ascii" if keep_ascii else "_tmp_ascii")

        fbx_dir = out_dir
        fbx_dir.mkdir(parents=True, exist_ok=True)

        # 为了满足“未勾选就连文件夹都不要”的要求：
        # - 如果固定目录（smd/ascii）存在且为空，则直接删除
        # - 临时目录会按脚本前缀删除，避免混入旧残留
        if not keep_smd:
            fixed_smd = out_dir / "smd"
            if fixed_smd.exists() and fixed_smd.is_dir() and not any(fixed_smd.iterdir()):
                try:
                    fixed_smd.rmdir()
                except OSError:
                    pass
            tmp_smd = out_dir / "_tmp_smd"
            if tmp_smd.exists():
                try:
                    shutil.rmtree(tmp_smd, ignore_errors=True)
                except OSError:
                    pass

        if not keep_ascii:
            fixed_ascii = out_dir / "ascii"
            if fixed_ascii.exists() and fixed_ascii.is_dir() and not any(fixed_ascii.iterdir()):
                try:
                    fixed_ascii.rmdir()
                except OSError:
                    pass
            tmp_ascii = out_dir / "_tmp_ascii"
            if tmp_ascii.exists():
                try:
                    shutil.rmtree(tmp_ascii, ignore_errors=True)
                except OSError:
                    pass

        start_btn.configure(state=tk.DISABLED)
        log_text = f"Starting: {len(dcx_paths)} .dcx file(s)\n"
        _append_log(root, log, log_text)

        try:
            tools = load_tools(script_dir)
        except Exception as e:  # noqa: BLE001
            _append_log(root, log, f"Failed to load tools: {e}")
            start_btn.configure(state=tk.NORMAL)
            return

        def worker():
            ok = 0
            total = len(dcx_paths)
            for i, dcx in enumerate(dcx_paths, start=1):
                _append_log(root, log, f"[{i}/{total}] Input: {dcx}")

                def log_fn(s: str):
                    _append_log(root, log, s)

                success = convert_one_dcx(
                    dcx,
                    yb_exe=yabber_exe,
                    bloodborne_exe=bloodborne_exe,
                    fbx_dir=fbx_dir,
                    smd_dir=smd_dir,
                    ascii_dir=ascii_dir,
                    fbx_kinds=fbx_kinds,
                    skip_existing=bool(skip_existing_var.get()),
                    keep_smd=bool(keep_smd_var.get()),
                    keep_ascii=bool(keep_ascii_var.get()),
                    keep_flver=bool(keep_flver_var.get()),
                    keep_xml=bool(keep_xml_var.get()),
                    tools=tools,
                    log=log_fn,
                )
                if success:
                    ok += 1
                _append_log(root, log, f"[{i}/{total}] Done, success so far: {ok}")

            _append_log(root, log, f"All done: {ok}/{total} succeeded")
            root.after(0, lambda: start_btn.configure(state=tk.NORMAL))
            root.after(0, lambda: messagebox.showinfo("Done", f"Succeeded: {ok}/{total}"))

        threading.Thread(target=worker, daemon=True).start()

    start_btn.configure(command=on_start)

    log = _build_log_widget(root)

    # 应用上次保存的状态（如果存在）
    try:
        y = state.get("yabber_exe")
        b = state.get("bloodborne_exe")
        o = state.get("out_dir")
        if y:
            yabber_exe = Path(y)
            yabber_path_lbl.configure(text=yabber_exe.as_posix())
        if b:
            bloodborne_exe = Path(b)
            bloodborne_path_lbl.configure(text=bloodborne_exe.as_posix())
        if o:
            out_dir = Path(o)
            out_path_lbl.configure(text=out_dir.as_posix())
        fbx_kind_var.set(state.get("fbx_kind", "binary"))
        skip_existing_var.set(bool(state.get("skip_existing", False)))
        keep_flver_var.set(bool(state.get("keep_flver", False)))
        keep_xml_var.set(bool(state.get("keep_xml", False)))
    except Exception:
        pass

    # 预填 initial inputs（如果有）
    if initial_inputs:
        dcx_list.extend(initial_inputs)
        refresh_listbox()
        _append_log(root, log, f"Startup args detected, prefilled {len(initial_inputs)} item(s).")

    def save_state_now():
        state["keep_smd"] = bool(keep_smd_var.get())
        state["keep_ascii"] = bool(keep_ascii_var.get())
        state["keep_flver"] = bool(keep_flver_var.get())
        state["keep_xml"] = bool(keep_xml_var.get())
        state["fbx_kind"] = fbx_kind_var.get()
        state["skip_existing"] = bool(skip_existing_var.get())
        set_state_path("yabber_exe", yabber_exe)
        set_state_path("bloodborne_exe", bloodborne_exe)
        set_state_path("out_dir", out_dir)
        try:
            state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    # 在关闭窗口时保存一次
    def on_close():
        save_state_now()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)

    # 开始转换前保存一次（避免中途异常丢配置）
    old_on_start = on_start
    def on_start_wrapper():
        save_state_now()
        return old_on_start()
    start_btn.configure(command=on_start_wrapper)

    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

