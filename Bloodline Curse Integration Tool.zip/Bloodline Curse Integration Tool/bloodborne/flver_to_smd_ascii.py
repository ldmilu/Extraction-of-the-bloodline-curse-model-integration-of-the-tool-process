import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def run_converter(exe_path: Path, flver_path: Path) -> None:
    if not exe_path.is_file():
        raise FileNotFoundError(f"找不到转换程序: {exe_path}")
    if not flver_path.is_file():
        raise FileNotFoundError(f"找不到 FLVER 文件: {flver_path}")

    # BloodBorne_model.exe 的典型用法是把 FLVER 拖到 exe 上，
    # 我们在这里等价地通过命令行调用。
    try:
        # 一些版本的 BloodBorne_model.exe 会把输出写到“当前工作目录”，
        # 为了让输出和 FLVER 在同目录，显式设置 cwd。
        completed = subprocess.run(
            [str(exe_path), str(flver_path)],
            check=True,
            cwd=str(flver_path.parent),
        )
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(f"调用转换程序失败，退出码 {exc.returncode}") from exc


def move_outputs(flver_path: Path, out_dir: Path) -> None:
    stem = flver_path.stem
    src_dir = flver_path.parent
    flver_name = flver_path.name  # 例如 xxx.flver

    candidates = [
        src_dir / f"{stem}.smd",
        src_dir / f"{stem}.SMD",
        src_dir / f"{stem}.ascii",
        src_dir / f"{stem}.ASCII",
        # 兜底：有些工具可能把前缀保留为完整 flver 文件名
        src_dir / f"{flver_name}.smd",
        src_dir / f"{flver_name}.SMD",
        src_dir / f"{flver_name}.ascii",
        src_dir / f"{flver_name}.ASCII",
    ]

    out_dir.mkdir(parents=True, exist_ok=True)

    moved_any = False
    for src in candidates:
        if src.is_file():
            dst = out_dir / src.name
            shutil.move(str(src), str(dst))
            print(f"已移动: {src} -> {dst}")
            moved_any = True

    if not moved_any:
        raise FileNotFoundError(
            f"在 {src_dir} 中未找到 {stem}.smd / {stem}.ascii 等输出文件，"
            "请检查 BloodBorne_model.exe 实际生成的文件名。"
        )


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="使用 BloodBorne_model.exe 将 FLVER 转换为 SMD 与 ASCII。"
    )
    parser.add_argument(
        "--flver",
        required=True,
        type=Path,
        help="输入的 .flver 模型文件路径",
    )
    parser.add_argument(
        "--exe",
        required=True,
        type=Path,
        help="BloodBorne_model.exe 的路径",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=None,
        help="输出目录（默认与 FLVER 同目录）",
    )

    args = parser.parse_args(argv)

    flver_path: Path = args.flver
    exe_path: Path = args.exe
    out_dir: Path = args.out_dir or flver_path.parent

    try:
        run_converter(exe_path, flver_path)
        move_outputs(flver_path, out_dir)
    except Exception as exc:  # noqa: BLE001
        print(f"转换失败: {exc}", file=sys.stderr)
        return 1

    print("转换完成。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

