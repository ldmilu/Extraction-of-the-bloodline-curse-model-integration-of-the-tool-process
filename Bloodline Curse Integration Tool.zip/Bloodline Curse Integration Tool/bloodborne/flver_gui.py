import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, scrolledtext

from flver_to_smd_ascii import move_outputs, run_converter


class FlverGui(tk.Tk):
    def __init__(self, initial_files: list[Path] | None = None) -> None:
        super().__init__()
        self.title("FLVER batch to SMD / ASCII")
        self.geometry("700x500")

        self.flver_paths: list[Path] = []
        self.exe_path: Path | None = None
        self.out_dir: Path | None = None

        self._build_widgets()

        if initial_files:
            self.set_flver_files(initial_files)

    def _build_widgets(self) -> None:
        # 顶部按钮区
        top_frame = tk.Frame(self)
        top_frame.pack(fill=tk.X, padx=10, pady=5)

        btn_select_flver = tk.Button(
            top_frame,
            text="Select FLVER files (multi-select)",
            command=self.select_flver_files,
        )
        btn_select_flver.pack(side=tk.LEFT, padx=5)

        btn_select_exe = tk.Button(
            top_frame,
            text="BloodBorne_model.exe…",
            command=self.select_exe,
        )
        btn_select_exe.pack(side=tk.LEFT, padx=5)

        btn_select_out = tk.Button(
            top_frame,
            text="Output folder…",
            command=self.select_out_dir,
        )
        btn_select_out.pack(side=tk.LEFT, padx=5)

        # 中部列表显示当前选择
        mid_frame = tk.LabelFrame(self, text="Selected FLVER files")
        mid_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.listbox = tk.Listbox(mid_frame, selectmode=tk.EXTENDED)
        self.listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # 底部输出及开始按钮
        bottom_frame = tk.Frame(self)
        bottom_frame.pack(fill=tk.X, padx=10, pady=5)

        self.status_label = tk.Label(bottom_frame, text="Ready.")
        self.status_label.pack(side=tk.LEFT)

        btn_start = tk.Button(
            bottom_frame,
            text="Start",
            command=self.start_convert_thread,
        )
        btn_start.pack(side=tk.RIGHT, padx=5)

        # 日志窗口
        log_frame = tk.LabelFrame(self, text="Log")
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            wrap=tk.WORD,
            height=8,
            state=tk.DISABLED,
        )
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def log(self, msg: str) -> None:
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.insert(tk.END, msg + "\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state=tk.DISABLED)

    def set_flver_files(self, paths: list[Path]) -> None:
        self.flver_paths = paths
        self.listbox.delete(0, tk.END)
        for p in self.flver_paths:
            self.listbox.insert(tk.END, str(p))
        self.log(f"Loaded {len(self.flver_paths)} FLVER file(s) from drag-and-drop or command line.")

    def select_flver_files(self) -> None:
        paths = filedialog.askopenfilenames(
            title="Select FLVER files (multi-select)",
            filetypes=[("FLVER files", "*.flver"), ("All files", "*.*")],
        )
        if not paths:
            return

        self.flver_paths = [Path(p) for p in paths]
        self.listbox.delete(0, tk.END)
        for p in self.flver_paths:
            self.listbox.insert(tk.END, str(p))

        self.log(f"Selected {len(self.flver_paths)} FLVER file(s).")

    def select_exe(self) -> None:
        path = filedialog.askopenfilename(
            title="Select BloodBorne_model.exe",
            filetypes=[("Executables", "*.exe"), ("All files", "*.*")],
        )
        if not path:
            return
        self.exe_path = Path(path)
        self.log(f"Converter: {self.exe_path}")

    def select_out_dir(self) -> None:
        path = filedialog.askdirectory(
            title="Select output folder (optional; default: same as FLVER)",
        )
        if not path:
            return
        self.out_dir = Path(path)
        self.log(f"Output folder: {self.out_dir}")

    def start_convert_thread(self) -> None:
        if not self.flver_paths:
            messagebox.showwarning("Notice", "Please select at least one FLVER file.")
            return
        if self.exe_path is None:
            messagebox.showwarning("Notice", "Please select BloodBorne_model.exe.")
            return

        thread = threading.Thread(target=self.convert_all, daemon=True)
        thread.start()

    def convert_all(self) -> None:
        self.status_label.config(text="Converting, please wait…")
        total = len(self.flver_paths)
        success = 0

        for idx, flver in enumerate(self.flver_paths, start=1):
            try:
                self.log(f"[{idx}/{total}] Start: {flver}")
                run_converter(self.exe_path, flver)  # type: ignore[arg-type]
                move_outputs(flver, self.out_dir or flver.parent)
                success += 1
                self.log(f"[{idx}/{total}] OK: {flver}")
            except Exception as exc:  # noqa: BLE001
                self.log(f"[{idx}/{total}] Failed: {flver} -> {exc}")

        self.status_label.config(text=f"Done. Succeeded {success} / {total}.")
        messagebox.showinfo("Done", f"Finished. Succeeded {success} / {total}.")


def main() -> None:
    # 支持把 FLVER 文件拖到 flver_gui.py / 打包后的 exe 图标上：
    # 系统会把文件路径作为 argv 传入，这里自动填充到列表里。
    initial_files: list[Path] = []
    if len(sys.argv) > 1:
        for arg in sys.argv[1:]:
            p = Path(arg)
            if p.is_file():
                initial_files.append(p)

    app = FlverGui(initial_files=initial_files)
    app.mainloop()


if __name__ == "__main__":
    main()

