### FLVER 转换为 SMD 与 ASCII

本目录下的 `flver_to_smd_ascii.py` 是一个在 Windows 上使用的简单脚本，用来调用社区工具 **BloodBorne_model.exe**，把血源诅咒的 `*.flver` 模型转换为 SMD 和 ASCII 文件。

#### 准备工作

- **安装 Python 3.8+**
- 从社区帖子（例如 ZenHAX 的 BloodBorne models 主题）下载 `BloodBorne_model.exe` 到任意位置。示例链接（请用浏览器打开）：
  - [BloodBorne models 工具帖](https://zenhax.com/viewtopic.php@t=7006.html)

#### 使用方法

在 `PowerShell` 或 `CMD` 中进入本目录：

```bash
cd a:\moxing_jiebao\gongju\bloodborne
```

执行脚本（示例）：

```bash
python flver_to_smd_ascii.py ^
  --flver "a:\moxing_jiebao\xueyuan\dcx\m22_00_00_00\m22_00_00_00_000002.flver" ^
  --exe   "a:\tools\BloodBorne_model.exe" ^
  --out-dir "a:\moxing_jiebao\gongju\bloodborne\output"
```

- **`--flver`**: 要转换的 FLVER 文件路径  
- **`--exe`**: `BloodBorne_model.exe` 的完整路径  
- **`--out-dir`**: 输出目录（可选，不填则输出到 FLVER 同目录）

脚本会：

1. 调用 `BloodBorne_model.exe` 对指定的 `.flver` 文件进行转换  
2. 在 FLVER 同目录中查找 `同名.smd` 和 `同名.ascii`（不区分大小写）  
3. 把找到的输出文件移动到指定的 `--out-dir` 目录

如果转换失败或找不到输出文件，脚本会在控制台打印错误信息。

