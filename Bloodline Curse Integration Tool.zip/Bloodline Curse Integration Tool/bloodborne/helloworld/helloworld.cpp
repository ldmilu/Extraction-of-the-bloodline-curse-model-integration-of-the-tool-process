﻿// helloworld.cpp: 定义应用程序的入口点。
//

#include <fmt/core.h>

int main()
{
    fmt::print("Hello World!\n");
    return 0;
}