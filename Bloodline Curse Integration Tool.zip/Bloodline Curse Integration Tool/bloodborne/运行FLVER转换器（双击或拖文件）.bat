@echo off
REM 简单的启动脚本：
REM 1. 直接双击：只打开 GUI，自行在界面里选文件
REM 2. 把 .flver 文件拖到这个 .bat 上：自动把这些文件传给 GUI

setlocal
cd /d "%~dp0"

REM 如果你安装了多个 Python，可以在这里改成 python3 / py 等
set PYTHON_EXE=python

"%PYTHON_EXE%" "flver_gui.py" %*

endlocal

